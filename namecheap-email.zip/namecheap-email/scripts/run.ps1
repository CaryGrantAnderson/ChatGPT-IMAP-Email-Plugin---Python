$ErrorActionPreference = 'Stop'
$runtimePython = Join-Path $env:LOCALAPPDATA 'NamecheapEmail\runtime\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $runtimePython)) {
    [Console]::Error.WriteLine('Namecheap Email runtime is missing. Run Install Plugin.ps1 first.')
    exit 1
}
& $runtimePython -B (Join-Path $PSScriptRoot 'server.py')
exit $LASTEXITCODE
